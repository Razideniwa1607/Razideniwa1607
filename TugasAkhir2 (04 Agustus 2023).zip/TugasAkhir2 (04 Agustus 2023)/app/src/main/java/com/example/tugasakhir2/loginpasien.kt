package com.example.tugasakhir2
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

class LoginPasienActivity : AppCompatActivity() {
    private lateinit var idEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: Button

    private val loginUrl = "http://10.0.2.2/ta%202/loginpasien.php"
    private val dataUrl = "http://10.0.2.2/ta%202/getdatapasien.php?Nomorindek="
    private val dataUrl2 = "http://10.0.2.2/ta%202/getdatapasientrimester2.php?Nomorindek="
    private val dataUrl3 = "http://10.0.2.2/ta%202/getdatapasientrimester3.php?Nomorindek="

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.loginpasien)

        idEditText = findViewById(R.id.id)
        passwordEditText = findViewById(R.id.password)
        loginButton = findViewById(R.id.login)

        loginButton.setOnClickListener {
            val nomorindek = idEditText.text.toString()
            val password = passwordEditText.text.toString()

            login(nomorindek, password)
        }
    }

    private fun login(nomorindek: String, password: String) {
        val requestQueue = Volley.newRequestQueue(this)
        val stringRequest = object : StringRequest(
            Request.Method.POST, loginUrl,
            Response.Listener { response ->
                val jsonObject = JSONObject(response)
                val serverResponseArray = jsonObject.getJSONArray("server_response")
                val firstObjectInArray = serverResponseArray.getJSONObject(0)
                val success = firstObjectInArray.getString("status")

                if (success == "OK") {

                    getData(nomorindek)
                    getDataTrimester2(nomorindek)
                    getDataTrimester3(nomorindek)
                } else {
                    Toast.makeText(this, "ID atau password salah", Toast.LENGTH_SHORT).show()
                }
            },
            Response.ErrorListener { error ->
                Toast.makeText(this, "Terjadi kesalahan: ${error.message}", Toast.LENGTH_SHORT).show()
            }) {
            override fun getParams(): MutableMap<String, String> {
                val params = HashMap<String, String>()
                params["Nomorindek"] = nomorindek
                params["Password"] = password
                return params
            }
        }

        requestQueue.add(stringRequest)
    }


    private fun getData(nomorindek: String) {
        val requestQueue = Volley.newRequestQueue(this)
        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.GET, dataUrl + nomorindek, null,
            Response.Listener { response ->
                val serverResponseArray = response.getJSONArray("server_response")
                val firstObjectInArray = serverResponseArray.getJSONObject(0)
                val sharedPreferences = getSharedPreferences("DataPasien", Context.MODE_PRIVATE)
                val editor = sharedPreferences.edit()

                for (key in firstObjectInArray.keys()) {
                    editor.putString(key, firstObjectInArray.getString(key))
                }

                editor.apply()

                val intent = Intent(this, MenuUtamaPasienActivity::class.java)
                startActivity(intent)
                finish()
            },
            Response.ErrorListener { error ->
                Toast.makeText(this, "Terjadi kesalahan saat mendapatkan data: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        )

        requestQueue.add(jsonObjectRequest)


    }

    private fun getDataTrimester2(nomorindek: String) {
        val requestQueue = Volley.newRequestQueue(this)
        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.GET, dataUrl2 + nomorindek, null,
            Response.Listener { response ->
                val serverResponseArray = response.getJSONArray("server_response")
                val firstObjectInArray = serverResponseArray.getJSONObject(0)
                val sharedPreferences = getSharedPreferences("DataPasienTrimester2", Context.MODE_PRIVATE)
                val editor = sharedPreferences.edit()

                for (key in firstObjectInArray.keys()) {
                    editor.putString(key, firstObjectInArray.getString(key))
                }

                editor.apply()
            },
            Response.ErrorListener { error ->
                Toast.makeText(this, "Terjadi kesalahan saat mendapatkan data: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        )

        requestQueue.add(jsonObjectRequest)
    }

    private fun getDataTrimester3(nomorindek: String) {
        val requestQueue = Volley.newRequestQueue(this)
        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.GET, dataUrl3 + nomorindek, null,
            Response.Listener { response ->
                val serverResponseArray = response.getJSONArray("server_response")
                val firstObjectInArray = serverResponseArray.getJSONObject(0)
                val sharedPreferences = getSharedPreferences("DataPasienTrimester3", Context.MODE_PRIVATE)
                val editor = sharedPreferences.edit()

                for (key in firstObjectInArray.keys()) {
                    editor.putString(key, firstObjectInArray.getString(key))
                }

                editor.apply()
            },
            Response.ErrorListener { error ->
                Toast.makeText(this, "Terjadi kesalahan saat mendapatkan data: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        )

        requestQueue.add(jsonObjectRequest)
    }
}
