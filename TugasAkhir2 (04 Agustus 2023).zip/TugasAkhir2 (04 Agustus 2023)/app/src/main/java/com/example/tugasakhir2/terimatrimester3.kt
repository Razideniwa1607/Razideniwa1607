package com.example.tugasakhir2

import android.content.Context
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class TerimaTrimester3Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.datapasien2)

        val sharedPreferences = getSharedPreferences("DataPasienTrimester3", Context.MODE_PRIVATE)
        findViewById<TextView>(R.id.nomorindek)?.text = sharedPreferences.getString("Nomor Indek", "")
        findViewById<TextView>(R.id.beratBadan)?.text = sharedPreferences.getString("Berat badan", "")
        findViewById<TextView>(R.id.tinggiBadan)?.text = sharedPreferences.getString("Tinggi badan", "")
        findViewById<TextView>(R.id.lila)?.text = sharedPreferences.getString("LiLa", "")
        findViewById<TextView>(R.id.imt)?.text = sharedPreferences.getString("IMT", "")
        findViewById<TextView>(R.id.hb)?.text = sharedPreferences.getString("HB", "")
        findViewById<TextView>(R.id.golDarah)?.text = sharedPreferences.getString("Gol darah", "")
        findViewById<TextView>(R.id.tensiDarah)?.text = sharedPreferences.getString("Tensi Darah", "")
        findViewById<TextView>(R.id.rot)?.text = sharedPreferences.getString("ROT", "")
        findViewById<TextView>(R.id.map)?.text = sharedPreferences.getString("MAP", "")
        findViewById<TextView>(R.id.pendeteksiFaktorRisiko)?.text = sharedPreferences.getString("Pendeteksi Faktor Risiko", "")
        findViewById<TextView>(R.id.jarakKehamilan)?.text = sharedPreferences.getString("Jarak Kehamilan", "")
        findViewById<TextView>(R.id.statusImunisasiTT)?.text = sharedPreferences.getString("Status Imunisasi TT", "")
        findViewById<TextView>(R.id.pemberianImunisasi)?.text = sharedPreferences.getString("Pemberian Imunisasi", "")
    }
}

