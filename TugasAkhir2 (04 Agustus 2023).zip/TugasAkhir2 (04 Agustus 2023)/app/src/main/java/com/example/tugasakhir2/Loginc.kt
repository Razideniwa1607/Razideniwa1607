package com.example.tugasakhir2

import android.content.Intent
import android.os.Bundle
import android.view.View

import androidx.appcompat.app.AppCompatActivity




class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login) // Ganti dengan layout yang benar
    }

    fun loginBidanActivity(view: View) {
        val intent = Intent(this, LoginBidanActivity::class.java)
        startActivity(intent)
    }
//
    fun loginPasienActivity(view: View) {
        val intent = Intent(this, LoginPasienActivity::class.java)
        startActivity(intent)
    }


}