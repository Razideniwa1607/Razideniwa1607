package com.example.tugasakhir2

import android.content.Intent
import android.os.Bundle
import android.view.View

import androidx.appcompat.app.AppCompatActivity




class PilihTrimesterPasienActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.pilihterimadata) // Ganti dengan layout yang benar
    }

    fun terimatrimester1Activity(view: View) {
        val intent = Intent(this, TerimaTrimester1Activity::class.java)
        startActivity(intent)
    }
    //
    fun terimatrimester2Activity(view: View) {
        val intent = Intent(this, TerimaTrimester2Activity::class.java)
        startActivity(intent)
    }

    fun terimatrimester3Activity(view: View) {
        val intent = Intent(this, TerimaTrimester3Activity::class.java)
        startActivity(intent)
    }
}