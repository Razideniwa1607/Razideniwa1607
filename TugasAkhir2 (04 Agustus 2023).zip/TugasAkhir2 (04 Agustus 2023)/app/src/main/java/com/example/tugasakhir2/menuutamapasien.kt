package com.example.tugasakhir2
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AlertDialog

class MenuUtamaPasienActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.menuutamapasien)

        val identitasButton: Button = findViewById(R.id.identitas)
        val quizButton: Button = findViewById(R.id.quiz)
        val logoutButton: Button = findViewById(R.id.logout)

    identitasButton.setOnClickListener {
            val intent = Intent(this, PilihTrimesterPasienActivity::class.java)
            startActivity(intent)
        }
        quizButton.setOnClickListener {
            val intent = Intent(this, PilihQuizActivity ::class.java)
            startActivity(intent)
        }
        logoutButton.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Apakah anda yakin mau logout?")
                .setPositiveButton("Ya") { _, _ ->
                    // Ganti ini dengan mekanisme logout Anda
                    val intent = Intent(this, LoginBidanActivity::class.java)
                    startActivity(intent)
                    finish()
                }
                .setNegativeButton("Tidak") { dialog, _ ->
                    dialog.dismiss()
                }
                .create()
                .show()
        }
    }
}

