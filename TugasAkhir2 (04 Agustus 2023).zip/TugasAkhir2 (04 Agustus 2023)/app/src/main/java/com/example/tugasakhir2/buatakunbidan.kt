package com.example.tugasakhir2
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException
import org.json.JSONObject

class BuatAkunBidanActivity : AppCompatActivity() {
    private lateinit var ID: EditText
    private lateinit var Password: EditText
    private lateinit var BuatakunButton: Button
    private val urlFinal = "http://10.0.2.2/ta%202/buatakunbidan.php"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.identitasbidan) // You would need to adjust your layout accordingly

        ID= findViewById(R.id.id)
        Password = findViewById(R.id.password)
        BuatakunButton = findViewById(R.id.buatakun)

        BuatakunButton.setOnClickListener {
            if (isAnyFieldEmpty()) {
                Toast.makeText(this, "Lengkapi semua kolom", Toast.LENGTH_SHORT).show()
            } else {
                val queue = Volley.newRequestQueue(this)

                val paramsFinal = JSONObject()
                paramsFinal.put("ID", ID.text.toString())
                paramsFinal.put("Password", Password.text.toString()) // Note: You would usually hash or encrypt this in real-world use

                val requestFinal = JsonObjectRequest(
                    Request.Method.POST, urlFinal, paramsFinal,
                    Response.Listener<JSONObject> { response ->
                        try {
                            val serverResponse = response.getJSONArray("server_response")
                            val status = serverResponse.getJSONObject(0).getString("status")
                            if (status == "OK") {
                                Toast.makeText(this, "Data berhasil disimpan", Toast.LENGTH_LONG).show()
                                finish()
                            } else {
                                Toast.makeText(this, "Gagal menyimpan data", Toast.LENGTH_LONG).show()
                            }
                        } catch (e: JSONException) {
                            Toast.makeText(this, "Gagal mengurai response: $response", Toast.LENGTH_LONG).show()
                        }
                    },
                    Response.ErrorListener { error ->
                        Toast.makeText(this, "Error: $error", Toast.LENGTH_LONG).show()
                    }
                )
                queue.add(requestFinal)
            }
        }
    }

    private fun isAnyFieldEmpty(): Boolean {
        return ID.text.isNullOrEmpty() || Password.text.isNullOrEmpty()
    }
}

