
package com.example.tugasakhir2
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException
import org.json.JSONObject

class Halaman2Activity : AppCompatActivity() {
    private lateinit var simpanButton: Button
    private val urlFinal = "http://10.0.2.2/ta%202/ta2final.php"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_halaman2data)

        simpanButton = findViewById(R.id.simpan_button)

        val nomorindek = intent.getStringExtra("nomorindek") ?: ""
        val ibu = intent.getStringExtra("ibu") ?: ""
        val suami = intent.getStringExtra("suami") ?: ""
        val alamat = intent.getStringExtra("alamat") ?: ""
        val umur = intent.getStringExtra("umur") ?: ""
        val hpht = intent.getStringExtra("hpht") ?: ""
        val u_kehamilan = intent.getStringExtra("ukehamilan") ?: ""
        val perkiraan = intent.getStringExtra("perkiraan") ?: ""
        val hamil_ke = intent.getStringExtra("hamilke") ?: ""
        val beratBadan = intent.getStringExtra("beratBadan") ?: ""
        val tinggiBadan = intent.getStringExtra("tinggiBadan") ?: ""
        val lila = intent.getStringExtra("lila") ?: ""
        val imt = intent.getStringExtra("imt") ?: ""
        val hb = intent.getStringExtra("hb") ?: ""
        val golDarah = intent.getStringExtra("golDarah") ?: ""
        val tensiDarah = intent.getStringExtra("tensiDarah") ?: ""
        val rot = intent.getStringExtra("rot") ?: ""
        val map = intent.getStringExtra("map") ?: ""
        val pendeteksiFaktorRisiko = intent.getStringExtra("pendeteksiFaktorRisiko") ?: ""
        val skorRisiko = intent.getStringExtra("skorRisiko") ?: ""
        val jarakKehamilan = intent.getStringExtra("jarakKehamilan") ?: ""
        val statusImunisasiTT = intent.getStringExtra("statusImunisasiTT") ?: ""
        val pemberianImunisasi = intent.getStringExtra("pemberianImunisasi") ?: ""

        simpanButton.setOnClickListener {
            val queue = Volley.newRequestQueue(this)

            val paramsFinal = HashMap<String, String>()
            paramsFinal["Nomorindek"] = nomorindek
            paramsFinal["Ibu"] = ibu
            paramsFinal["Suami"] = suami
            paramsFinal["Alamat"] = alamat
            paramsFinal["Umur"] = umur
            paramsFinal["HPHT"] = hpht
            paramsFinal["U_Kehamilan"] = u_kehamilan
            paramsFinal["Perkiraan_Lahir"] = perkiraan
            paramsFinal["Hamil_ke"] = hamil_ke
            paramsFinal["BeratBadan"] = beratBadan
            paramsFinal["TinggiBadan"] = tinggiBadan
            paramsFinal["LiLa"] = lila
            paramsFinal["IMT"] = imt
            paramsFinal["HB"] = hb
            paramsFinal["GolDarah"] = golDarah
            paramsFinal["TensiDarah"] = tensiDarah
            paramsFinal["ROT"] = rot
            paramsFinal["MAP"] = map
            paramsFinal["PendeteksiFaktorRisiko"] = pendeteksiFaktorRisiko
            paramsFinal["SkorRisiko"] = skorRisiko
            paramsFinal["JarakKehamilan"] = jarakKehamilan
            paramsFinal["StatusImunisasiTT"] = statusImunisasiTT
            paramsFinal["PemberianImunisasi"] = pemberianImunisasi

            val requestFinal = object : StringRequest(
                Request.Method.POST, urlFinal,
                Response.Listener<String> { response ->
                    try {
                        val jsonResponse = JSONObject(response)
                        val status = jsonResponse.getString("status")
                        if (status == "OK") {
                            Toast.makeText(this, "Data berhasil disimpan", Toast.LENGTH_LONG).show()
                            val resultIntent = Intent()
                            resultIntent.putStringArrayListExtra("mitoma", ArrayList(paramsFinal.values))
                            setResult(Activity.RESULT_OK, resultIntent)
                            finish()
                        } else {
                            Toast.makeText(this, "Gagal menyimpan data", Toast.LENGTH_LONG).show()
                        }
                    } catch (e: JSONException) {
                        Toast.makeText(this, "Gagal mengurai response: $response", Toast.LENGTH_LONG).show()
                    }
                },
                Response.ErrorListener { error ->
                    Toast.makeText(this, "Error: $error", Toast.LENGTH_LONG).show()
                }) {
                override fun getParams(): Map<String, String> {
                    return paramsFinal
                }
            }
            queue.add(requestFinal)
        }
    }
}

