package com.example.tugasakhir2;

import android.app.Application;

public class AppController extends Application {
}
