package com.example.tugasakhir2
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.content.Intent

class QuizTrimester2Activity : AppCompatActivity() {

    private lateinit var questionTextView: TextView
    private lateinit var optionButtons: List<Button>
    private var currentQuestionIndex = 0
    private val handler = Handler(Looper.getMainLooper())

    private var currentScore = 0
    private val maxScore = 10

    private val questions = listOf(
        Question("Berikut adalah cara untuk menjaga kebersihan diri, kecuali... ", listOf("Cuci tangan dengan sabun", "jaga kebersihan payudara dan daerah kemaluan", "Pakaian tidak diganti selama sehari", "Mandi dan gosok gigi 2 hari sekali"), 2),
        Question("Jumlah porsi nasi atau makanan pokok yang disarankan untuk ibu hamil di trimester 2 adalah....", listOf("4 Porsi", "5 Porsi", "6 Porsi", "7 Porsi"), 2),
        Question(" Aktivitas fisik yang diperbolehlkan untuk dilakukan oleh ibu hamil di trimester 2 namun tidak diperbolehkan di trimester 1 adalah .....", listOf("Senam hamil", "Aerobic", "Kegel exercise", "Pendinginan"), 0),
        // tambahkan soal lainnya
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.quiz)

        questionTextView = findViewById(R.id.rectangle_1)
        optionButtons = listOf(
            findViewById(R.id.opsi1),
            findViewById(R.id.opsi2),
            findViewById(R.id.opsi3),
            findViewById(R.id.opsi4)
        )

        val correctAnswer = Color.parseColor("#008000") // Hijau
        val wrongAnswer = Color.parseColor("#FF0000") // Merah

        for (i in optionButtons.indices) {
            optionButtons[i].setOnClickListener {
                val isCorrect = checkAnswer(i)
                optionButtons.forEachIndexed { index, button ->
                    if (index == questions[currentQuestionIndex].correctAnswerIndex) {
                        button.setBackgroundColor(correctAnswer)
                    } else if (index == i && !isCorrect) {
                        button.setBackgroundColor(wrongAnswer)
                    }
                }
                calculateScore(isCorrect)
                handler.postDelayed({
                    if (currentQuestionIndex < questions.size - 1) {
                        currentQuestionIndex++
                    } else {
                        val intent = Intent(this, HasilQuizActivity::class.java)
                        intent.putExtra("score", currentScore)
                        intent.putExtra("maxScore", questions.size * maxScore)
                        startActivity(intent)
                    }
                    updateUI()
                }, 1000) // Tambahkan penundaan 1 detik (1000ms) sebelum pindah ke pertanyaan berikutnya
            }
        }

        updateUI()
    }

    private fun updateUI() {
        questionTextView.text = questions[currentQuestionIndex].questionText
        optionButtons.forEachIndexed { index, button ->
            button.text = questions[currentQuestionIndex].answerOptions[index]
            button.setBackgroundColor(Color.TRANSPARENT) // Mengatur ulang warna latar belakang
        }
    }

    private fun checkAnswer(selectedOptionIndex: Int): Boolean {
        return selectedOptionIndex == questions[currentQuestionIndex].correctAnswerIndex
    }

    private fun calculateScore(isCorrect: Boolean) {
        if (isCorrect) {
            currentScore += maxScore
        }
    }

    data class Question(
        val questionText: String,
        val answerOptions: List<String>,
        val correctAnswerIndex: Int
    )
}
