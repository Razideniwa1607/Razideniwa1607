package com.example.tugasakhir2

import android.content.Intent
import android.os.Bundle
import android.view.View

import androidx.appcompat.app.AppCompatActivity




class PilihQuizActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.pilihquiz) // Ganti dengan layout yang benar
    }

    fun QuizTrimester1Activity(view: View) {
        val intent = Intent(this, QuizTrimester1Activity::class.java)
        startActivity(intent)
    }
//
    fun QuizTrimester2Activity(view: View) {
        val intent = Intent(this, QuizTrimester2Activity::class.java)
        startActivity(intent)
    }

    fun QuizTrimester3Activity(view: View) {
        val intent = Intent(this, QuizTrimester3Activity::class.java)
        startActivity(intent)
    }
}