package com.example.tugasakhir2

import android.content.Intent
import android.os.Bundle
import android.view.View

import androidx.appcompat.app.AppCompatActivity




class PilihTrimesterActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.pilihtrimester) // Ganti dengan layout yang benar
    }

    fun trimester1Activity(view: View) {
        val intent = Intent(this, Trimester1Activity::class.java)
        startActivity(intent)
    }
//
    fun trimester23Activity(view: View) {
        val intent = Intent(this, Trimester23Activity::class.java)
        startActivity(intent)
    }


}